package com.multiclone.pro

import com.multiclone.pro.data.CloneEntity
import com.multiclone.pro.domain.SortMode
import com.multiclone.pro.domain.filterAndSort
import org.junit.Assert.assertEquals
import org.junit.Test

class CloneLogicTest {
    private fun e(id: Long, name: String, pkg: String = "p.x", fav: Boolean = false, order: Int = 0, created: Long = 0) =
        CloneEntity(id = id, name = name, packageName = pkg, accentColor = 0, favorite = fav, sortOrder = order, createdAt = created)

    private val data = listOf(
        e(1, "Beta", "com.b", fav = true, order = 2, created = 10),
        e(2, "alpha", "com.a", order = 0, created = 30),
        e(3, "Gamma", "com.g", order = 1, created = 20),
    )

    @Test fun searchMatchesNameAndPackage() {
        assertEquals(listOf(2L), data.filterAndSort("ALP", false, SortMode.MANUAL).map { it.id })
        assertEquals(listOf(3L), data.filterAndSort("com.g", false, SortMode.MANUAL).map { it.id })
    }

    @Test fun favoritesOnly() {
        assertEquals(listOf(1L), data.filterAndSort("", true, SortMode.MANUAL).map { it.id })
    }

    @Test fun sortModes() {
        assertEquals(listOf(2L, 3L, 1L), data.filterAndSort("", false, SortMode.MANUAL).map { it.id })
        assertEquals(listOf(2L, 1L, 3L), data.filterAndSort("", false, SortMode.NAME).map { it.id })
        assertEquals(listOf(2L, 3L, 1L), data.filterAndSort("", false, SortMode.NEWEST).map { it.id })
    }
}
