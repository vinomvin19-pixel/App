package com.multiclone.counter

import org.junit.Assert.assertEquals
import org.junit.Test

class LogicTest {
    private fun n(pkg: String, sub: String, text: String, count: Int = 1, ongoing: Boolean = false) =
        NotifItem(pkg + sub + text, pkg, pkg, "t", text, sub, count, ongoing)

    private val data = listOf(
        n("m", "acc1", "hello", 2),
        n("m", "acc2", "Marketplace: is it available?"),
        n("x", "", "other"),
        n("m", "", "running", 1, ongoing = true),
    )

    @Test fun countsIgnoreOngoing() {
        assertEquals(4, summarize(data, emptySet(), "").total)
    }

    @Test fun watchedFilters() {
        assertEquals(3, summarize(data, setOf("m"), "").total)
    }

    @Test fun keywordMatches() {
        assertEquals(1, summarize(data, emptySet(), "marketplace, سوق").keywordCount)
    }

    @Test fun groupsSplitBySubtitle() {
        assertEquals(3, summarize(data, setOf("m"), "").groups.size.let { it + 1 })
    }
}
