package com.multiclone.pro.engine

import android.content.Context
import android.content.Intent
import com.multiclone.pro.R
import com.multiclone.pro.data.CloneEntity
import java.io.File

/**
 * Phase 1 engine. It creates a private directory per environment and launches the REAL
 * installed app. It does NOT isolate the app's data (Android forbids that without a
 * Work Profile or a virtualization engine), and capabilities say so honestly.
 */
class LauncherEngine(private val context: Context) : CloneEngine {
    override val capabilities = EngineCapabilities(
        name = "Launcher (Phase 1)",
        isolatesAppData = false,
        supportsMultipleInstances = false,
    )

    private fun dir(id: Long) = File(context.filesDir, "environments/$id")

    override suspend fun prepare(env: CloneEntity): Result<File> = runCatching {
        val d = dir(env.id)
        check(d.exists() || d.mkdirs()) { "cannot create ${d.name}" }
        File(d, "environment.properties").writeText("id=${env.id}\npackage=${env.packageName}\n")
        d
    }

    override suspend fun launch(env: CloneEntity): Result<Unit> = runCatching {
        val intent = context.packageManager.getLaunchIntentForPackage(env.packageName)
            ?: throw IllegalStateException(context.getString(R.string.msg_not_installed))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    override suspend fun destroy(env: CloneEntity): Result<Unit> = runCatching {
        val d = dir(env.id)
        check(!d.exists() || d.deleteRecursively()) { "cannot delete ${d.name}" }
    }

    override fun storageBytes(envId: Long): Long =
        dir(envId).walkTopDown().filter { it.isFile }.sumOf { it.length() }
}
