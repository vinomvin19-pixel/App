@file:OptIn(ExperimentalMaterial3Api::class)

package com.multiclone.pro.ui

import androidx.activity.compose.BackHandler
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.multiclone.pro.R
import com.multiclone.pro.domain.ThemeMode

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().selectable(selected, onClick = onClick, role = Role.RadioButton).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(label)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val state by vm.state.collectAsStateWithLifecycle()
    var lang by remember { mutableStateOf(AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore('-')) }
    val caps = vm.capabilities

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.settings)) },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back)) }
            },
        )
    }) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.theme), style = MaterialTheme.typography.titleSmall)
            listOf(ThemeMode.SYSTEM to R.string.theme_system, ThemeMode.LIGHT to R.string.theme_light, ThemeMode.DARK to R.string.theme_dark)
                .forEach { (m, r) -> RadioRow(stringResource(r), state.theme == m) { vm.setTheme(m) } }

            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.language), style = MaterialTheme.typography.titleSmall)
            listOf("" to R.string.lang_system, "en" to R.string.lang_en, "ar" to R.string.lang_ar).forEach { (tag, r) ->
                RadioRow(stringResource(r), lang == tag) {
                    lang = tag
                    AppCompatDelegate.setApplicationLocales(
                        if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag),
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.engine_section), style = MaterialTheme.typography.titleSmall)
            InfoRow(stringResource(R.string.engine_section), caps.name)
            InfoRow(stringResource(R.string.info_isolation), stringResource(if (caps.isolatesAppData) R.string.yes else R.string.no))
            InfoRow(stringResource(R.string.engine_multi), stringResource(if (caps.supportsMultipleInstances) R.string.yes else R.string.no))

            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.limitations_title), style = MaterialTheme.typography.titleSmall)
            Text(stringResource(R.string.limitations_body), style = MaterialTheme.typography.bodyMedium)
        }
    }
}
