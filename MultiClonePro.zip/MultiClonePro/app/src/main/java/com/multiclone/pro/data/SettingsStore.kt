package com.multiclone.pro.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.multiclone.pro.domain.SortMode
import com.multiclone.pro.domain.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsStore(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val sortKey = stringPreferencesKey("sort")

    private val prefs = context.dataStore.data.catch { if (it is IOException) emit(emptyPreferences()) else throw it }

    val themeMode: Flow<ThemeMode> = prefs.map { p ->
        p[themeKey]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM
    }
    val sortMode: Flow<SortMode> = prefs.map { p ->
        p[sortKey]?.let { runCatching { SortMode.valueOf(it) }.getOrNull() } ?: SortMode.MANUAL
    }

    suspend fun setTheme(mode: ThemeMode) { context.dataStore.edit { it[themeKey] = mode.name } }
    suspend fun setSort(mode: SortMode) { context.dataStore.edit { it[sortKey] = mode.name } }
}
