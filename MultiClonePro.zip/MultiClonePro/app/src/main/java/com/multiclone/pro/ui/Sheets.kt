@file:OptIn(ExperimentalMaterial3Api::class)

package com.multiclone.pro.ui

import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.multiclone.pro.R
import com.multiclone.pro.data.InstalledApp
import com.multiclone.pro.domain.Palette
import java.text.DateFormat
import java.util.Date

@Composable
fun AddSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.loadApps() }
    var q by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<InstalledApp?>(null) }
    var name by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        val sel = selected
        if (sel == null) {
            Column(Modifier.fillMaxWidth().fillMaxHeight(0.85f).padding(horizontal = 16.dp)) {
                Text(stringResource(R.string.pick_app), style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    placeholder = { Text(stringResource(R.string.search_hint)) },
                )
                val list = apps
                if (list == null) {
                    Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                } else {
                    val shown = list.filter { q.isBlank() || it.label.contains(q, true) || it.packageName.contains(q, true) }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(shown, key = { it.packageName }) { app ->
                            ListItem(
                                headlineContent = { Text(app.label) },
                                supportingContent = { Text(app.packageName) },
                                leadingContent = { AppIconImage(app.packageName, 40.dp) },
                                modifier = Modifier.clickable { selected = app; name = app.label },
                            )
                        }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIconImage(sel.packageName, 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(sel.label, style = MaterialTheme.typography.titleLarge)
                }
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.name_label)) },
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { selected = null }) { Text(stringResource(R.string.back)) }
                    Button(onClick = { vm.create(sel, name); onDismiss() }, enabled = name.isNotBlank()) {
                        Text(stringResource(R.string.create))
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun DetailsSheet(id: Long, vm: MainViewModel, canReorder: Boolean, onDismiss: () -> Unit) {
    val env by remember(id) { vm.observe(id) }.collectAsStateWithLifecycle(null)
    var seen by remember { mutableStateOf(false) }
    LaunchedEffect(env) { if (env != null) seen = true else if (seen) onDismiss() }
    val e = env ?: return
    val ctx = LocalContext.current
    var name by remember(e.name) { mutableStateOf(e.name) }
    var confirmDelete by remember { mutableStateOf(false) }
    val bytes by produceState(0L, e.id) { value = vm.storageBytes(e.id) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setCustomIcon(id, uri)
    }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                EnvIcon(e, 64.dp)
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true, modifier = Modifier.weight(1f),
                    label = { Text(stringResource(R.string.name_label)) },
                    trailingIcon = {
                        IconButton(onClick = { vm.rename(id, name) }, enabled = name.isNotBlank() && name.trim() != e.name) {
                            Icon(Icons.Rounded.Check, stringResource(R.string.save))
                        }
                    },
                )
            }
            Button(onClick = { vm.launch(id) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.launch))
            }

            Text(stringResource(R.string.icon_section), style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Palette.colors.forEach { c ->
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(Color(c)).clickable { vm.setAccent(id, c) },
                        contentAlignment = Alignment.Center,
                    ) { if (c == e.accentColor) Icon(Icons.Rounded.Check, null, tint = Color.White) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text(stringResource(R.string.choose_image))
                }
                OutlinedButton(onClick = { vm.resetIcon(id) }, enabled = e.customIconPath != null) {
                    Text(stringResource(R.string.use_app_icon))
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.favorite), Modifier.weight(1f))
                Switch(checked = e.favorite, onCheckedChange = { vm.toggleFavorite(id) })
            }
            if (canReorder) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.move(id, -1) }) { Text(stringResource(R.string.move_earlier)) }
                    OutlinedButton(onClick = { vm.move(id, 1) }) { Text(stringResource(R.string.move_later)) }
                }
            }

            HorizontalDivider()
            InfoRow(stringResource(R.string.info_package), e.packageName)
            InfoRow(stringResource(R.string.info_created), fmt.format(Date(e.createdAt)))
            InfoRow(stringResource(R.string.info_last_launched), e.lastLaunchedAt?.let { fmt.format(Date(it)) } ?: stringResource(R.string.info_never))
            InfoRow(stringResource(R.string.info_state), stateLabel(e.state))
            e.lastError?.let { InfoRow(stringResource(R.string.info_error), it) }
            InfoRow(stringResource(R.string.info_storage), Formatter.formatShortFileSize(ctx, bytes))
            InfoRow(stringResource(R.string.info_isolation), stringResource(if (vm.capabilities.isolatesAppData) R.string.yes else R.string.no))

            OutlinedButton(
                onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
            ) {
                Icon(Icons.Rounded.Delete, null); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.delete))
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_body, e.name)) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.delete(id) }) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
