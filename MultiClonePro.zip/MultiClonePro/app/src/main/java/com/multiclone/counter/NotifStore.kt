package com.multiclone.counter

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow

object NotifStore {
    val items = MutableStateFlow<List<NotifItem>>(emptyList())

    fun update(ctx: Context, list: List<NotifItem>) {
        items.value = list
        refreshBadge(ctx)
    }

    fun refreshBadge(ctx: Context) {
        BadgePoster.post(ctx, summarize(items.value, Prefs.watched(ctx), Prefs.keyword(ctx)))
    }
}

object BadgePoster {
    private const val CHANNEL = "counts"
    private const val ID = 1

    fun post(ctx: Context, s: Summary) {
        runCatching {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (s.total == 0) { nm.cancel(ID); return }
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val ch = NotificationChannel(CHANNEL, ctx.getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(true)
            nm.createNotificationChannel(ch)
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val text = if (s.keywordCount > 0) ctx.getString(R.string.notif_text_kw, s.keywordCount) else ctx.getString(R.string.notif_text)
            val n = Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(ctx.getString(R.string.notif_title, s.total))
                .setContentText(text)
                .setNumber(s.total)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setContentIntent(pi)
                .setBadgeIconType(Notification.BADGE_ICON_SMALL)
                .build()
            nm.notify(ID, n)
        }
    }
}
