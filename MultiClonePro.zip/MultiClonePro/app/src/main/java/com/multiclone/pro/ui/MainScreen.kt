@file:OptIn(ExperimentalMaterial3Api::class)

package com.multiclone.pro.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.multiclone.pro.R
import com.multiclone.pro.domain.SortMode

@StringRes
fun SortMode.labelRes() = when (this) {
    SortMode.MANUAL -> R.string.sort_manual
    SortMode.NAME -> R.string.sort_name
    SortMode.NEWEST -> R.string.sort_newest
}

@Composable
fun MainScreen(vm: MainViewModel, onOpenSettings: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it.resolve(ctx)) } }

    var showAdd by rememberSaveable { mutableStateOf(false) }
    var detailsId by rememberSaveable { mutableStateOf<Long?>(null) }
    var sortMenu by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold) },
                actions = {
                    Box {
                        IconButton(onClick = { sortMenu = true }) {
                            Icon(Icons.AutoMirrored.Rounded.Sort, stringResource(R.string.sort))
                        }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            SortMode.entries.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(m.labelRes())) },
                                    onClick = { vm.setSort(m); sortMenu = false },
                                    trailingIcon = { if (m == state.sort) Icon(Icons.Rounded.Check, null) },
                                )
                            }
                        }
                    }
                    IconButton(onClick = onOpenSettings) { Icon(Icons.Rounded.Settings, stringResource(R.string.settings)) }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text(stringResource(R.string.add_environment)) },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = state.query, onValueChange = vm::setQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                singleLine = true, shape = RoundedCornerShape(16.dp),
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (state.query.isNotEmpty()) IconButton(onClick = { vm.setQuery("") }) {
                        Icon(Icons.Rounded.Close, stringResource(R.string.clear))
                    }
                },
                placeholder = { Text(stringResource(R.string.search_hint)) },
            )
            Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !state.favoritesOnly, onClick = { vm.setFavoritesOnly(false) }, label = { Text(stringResource(R.string.filter_all)) })
                FilterChip(
                    selected = state.favoritesOnly, onClick = { vm.setFavoritesOnly(true) },
                    label = { Text(stringResource(R.string.filter_favorites)) },
                    leadingIcon = { Icon(Icons.Rounded.Star, null, Modifier.size(18.dp)) },
                )
            }
            if (!state.loaded) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    if (!vm.capabilities.isolatesAppData) {
                        item(key = "banner", span = { GridItemSpan(maxLineSpan) }) {
                            InfoBanner(stringResource(R.string.banner_phase1))
                        }
                    }
                    if (state.items.isEmpty()) {
                        item(key = "empty", span = { GridItemSpan(maxLineSpan) }) { EmptyState(state.storeEmpty) }
                    }
                    items(state.items, key = { it.id }) { env ->
                        CloneCard(
                            env,
                            onLaunch = { vm.launch(env.id) },
                            onDetails = { detailsId = env.id },
                            onFavorite = { vm.toggleFavorite(env.id) },
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
        }
    }

    if (showAdd) AddSheet(vm) { showAdd = false }
    detailsId?.let { id -> DetailsSheet(id, vm, state.canReorder) { detailsId = null } }
}
