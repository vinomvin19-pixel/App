package com.multiclone.pro.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.multiclone.pro.domain.ThemeMode

private val Light = lightColorScheme(
    primary = Color(0xFF4F5BD5), onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E3FF), secondary = Color(0xFF26A69A),
    background = Color(0xFFF7F7FB), surface = Color(0xFFFFFFFF),
)
private val Dark = darkColorScheme(
    primary = Color(0xFFA9B1FF), onPrimary = Color(0xFF111A78),
    primaryContainer = Color(0xFF343EAB), secondary = Color(0xFF80CBC4),
    background = Color(0xFF111218), surface = Color(0xFF1A1B23),
)

@Composable
fun MultiCloneTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
