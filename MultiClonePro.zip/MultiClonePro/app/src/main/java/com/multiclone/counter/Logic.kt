package com.multiclone.counter

data class NotifItem(
    val key: String,
    val pkg: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val sub: String,
    val count: Int,
    val ongoing: Boolean,
)

data class Group(val label: String, val count: Int)
data class Summary(val total: Int, val keywordCount: Int, val groups: List<Group>)

fun keywordsOf(raw: String): List<String> =
    raw.split(',', '،').map { it.trim() }.filter { it.isNotEmpty() }

/** Counts non-ongoing notifications; empty [watched] means every package. */
fun summarize(items: List<NotifItem>, watched: Set<String>, keyword: String): Summary {
    val kws = keywordsOf(keyword)
    val counted = items.filter { !it.ongoing && (watched.isEmpty() || it.pkg in watched) }
    val groups = counted
        .groupBy { if (it.sub.isBlank()) it.appLabel else "${it.appLabel} · ${it.sub}" }
        .map { (label, list) -> Group(label, list.sumOf { it.count }) }
        .sortedByDescending { it.count }
    val kwCount = if (kws.isEmpty()) 0 else counted
        .filter { i -> kws.any { k -> i.title.contains(k, true) || i.text.contains(k, true) || i.sub.contains(k, true) } }
        .sumOf { it.count }
    return Summary(counted.sumOf { it.count }, kwCount, groups)
}
