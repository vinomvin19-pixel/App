package com.multiclone.pro

import android.content.Context
import com.multiclone.pro.data.AppDatabase
import com.multiclone.pro.data.CloneRepository
import com.multiclone.pro.data.InstalledAppsSource
import com.multiclone.pro.data.SettingsStore
import com.multiclone.pro.engine.CloneEngine
import com.multiclone.pro.engine.LauncherEngine

/** Manual dependency container. Swap [engine] to change the isolation backend. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val db = AppDatabase.create(appContext)
    val engine: CloneEngine = LauncherEngine(appContext)
    val repository = CloneRepository(appContext, db.dao(), engine)
    val settings = SettingsStore(appContext)
    val installedApps = InstalledAppsSource(appContext)
}
