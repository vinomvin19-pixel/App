package com.multiclone.pro.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CloneDao {
    @Query("SELECT * FROM environments")
    fun observeAll(): Flow<List<CloneEntity>>

    @Query("SELECT * FROM environments ORDER BY sortOrder, id")
    suspend fun getAllOnce(): List<CloneEntity>

    @Query("SELECT * FROM environments WHERE id = :id")
    suspend fun get(id: Long): CloneEntity?

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM environments")
    suspend fun maxOrder(): Int

    @Insert
    suspend fun insert(entity: CloneEntity): Long

    @Update
    suspend fun update(entity: CloneEntity)

    @Update
    suspend fun updateAll(entities: List<CloneEntity>)

    @Query("DELETE FROM environments WHERE id = :id")
    suspend fun delete(id: Long)
}
