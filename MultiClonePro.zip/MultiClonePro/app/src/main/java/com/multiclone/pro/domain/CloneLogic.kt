package com.multiclone.pro.domain

import com.multiclone.pro.data.CloneEntity

enum class SortMode { MANUAL, NAME, NEWEST }
enum class ThemeMode { SYSTEM, LIGHT, DARK }

object Palette {
    val colors: List<Int> = listOf(
        0xFF5C6BC0, 0xFF26A69A, 0xFFEF5350, 0xFFFFA726,
        0xFFAB47BC, 0xFF42A5F5, 0xFF66BB6A, 0xFFEC407A,
    ).map { it.toInt() }

    fun pick(index: Int): Int = colors[Math.floorMod(index, colors.size)]
}

fun List<CloneEntity>.filterAndSort(query: String, favoritesOnly: Boolean, sort: SortMode): List<CloneEntity> {
    val q = query.trim()
    val filtered = filter { e ->
        (!favoritesOnly || e.favorite) &&
            (q.isEmpty() || e.name.contains(q, ignoreCase = true) || e.packageName.contains(q, ignoreCase = true))
    }
    return when (sort) {
        SortMode.MANUAL -> filtered.sortedWith(compareBy({ it.sortOrder }, { it.id }))
        SortMode.NAME -> filtered.sortedBy { it.name.lowercase() }
        SortMode.NEWEST -> filtered.sortedByDescending { it.createdAt }
    }
}
