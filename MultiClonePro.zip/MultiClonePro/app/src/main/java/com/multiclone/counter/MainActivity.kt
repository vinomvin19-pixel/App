package com.multiclone.counter

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val listenerOn = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen(listenerOn.value) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        listenerOn.value = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
    }
}

@Composable
private fun Screen(listenerOn: Boolean) {
    val ctx = LocalContext.current
    val items by NotifStore.items.collectAsStateWithLifecycle()
    var watched by remember { mutableStateOf(Prefs.watched(ctx)) }
    var keyword by remember { mutableStateOf(Prefs.keyword(ctx)) }
    val summary = remember(items, watched, keyword) { summarize(items, watched, keyword) }
    var notifGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notifGranted = it
        NotifStore.refreshBadge(ctx)
    }
    val packages = remember(items) { items.map { it.pkg to it.appLabel }.distinct() }

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text(stringResource(R.string.app_name), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        if (!listenerOn) {
            item {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.setup_title), fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.setup_body))
                        Text(stringResource(R.string.setup_hint), style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                            Text(stringResource(R.string.setup_button))
                        }
                    }
                }
            }
        }
        if (!notifGranted) {
            item {
                Button(onClick = { permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                    Text(stringResource(R.string.perm_button))
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.total_label))
                    Text(summary.total.toString(), fontSize = 56.sp, fontWeight = FontWeight.Bold)
                    if (keyword.isNotBlank()) Text(stringResource(R.string.keyword_matches, summary.keywordCount))
                }
            }
        }
        item {
            OutlinedTextField(
                value = keyword,
                onValueChange = {
                    keyword = it
                    Prefs.setKeyword(ctx, it)
                    NotifStore.refreshBadge(ctx)
                },
                label = { Text(stringResource(R.string.keyword_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item { Text(stringResource(R.string.sources_title), fontWeight = FontWeight.SemiBold) }
        item { Text(stringResource(R.string.sources_hint), style = MaterialTheme.typography.bodySmall) }
        items(packages, key = { it.first }) { (pkg, label) ->
            Row(
                Modifier.fillMaxWidth().clickable {
                    val next = if (pkg in watched) watched - pkg else watched + pkg
                    watched = next
                    Prefs.setWatched(ctx, next)
                    NotifStore.refreshBadge(ctx)
                },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = pkg in watched, onCheckedChange = null)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(label)
                    Text(pkg, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text(stringResource(R.string.groups_title), fontWeight = FontWeight.SemiBold) }
        if (summary.groups.isEmpty()) {
            item { Text(stringResource(R.string.empty)) }
        }
        items(summary.groups, key = { it.label }) { g ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(g.label, Modifier.weight(1f))
                Text(g.count.toString(), fontWeight = FontWeight.Bold)
            }
        }
        item { Text(stringResource(R.string.recent_title), fontWeight = FontWeight.SemiBold) }
        items(items.take(40), key = { it.key }) { n ->
            Text(
                "${n.appLabel} | ${n.sub} | ${n.title} | ${n.text}",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 3,
            )
        }
        item { Text(stringResource(R.string.limits_note), style = MaterialTheme.typography.bodySmall) }
    }
}
