package com.multiclone.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class EnvState { READY, LAUNCHING, ERROR }

@Entity(tableName = "environments")
data class CloneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val packageName: String,
    val accentColor: Int,
    val customIconPath: String? = null,
    val favorite: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long,
    val lastLaunchedAt: Long? = null,
    val state: EnvState = EnvState.READY,
    val lastError: String? = null,
)
