package com.multiclone.pro

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.multiclone.pro.ui.MainScreen
import com.multiclone.pro.ui.MainViewModel
import com.multiclone.pro.ui.MultiCloneTheme
import com.multiclone.pro.ui.SettingsScreen

class MainActivity : AppCompatActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by vm.state.collectAsStateWithLifecycle()
            MultiCloneTheme(state.theme) {
                var showSettings by rememberSaveable { mutableStateOf(false) }
                AnimatedContent(targetState = showSettings, label = "nav") { settings ->
                    if (settings) SettingsScreen(vm) { showSettings = false }
                    else MainScreen(vm) { showSettings = true }
                }
            }
        }
    }
}
