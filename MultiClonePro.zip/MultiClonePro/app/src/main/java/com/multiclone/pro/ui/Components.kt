@file:OptIn(ExperimentalMaterial3Api::class)

package com.multiclone.pro.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.multiclone.pro.R
import com.multiclone.pro.data.CloneEntity
import com.multiclone.pro.data.EnvState

private fun appIcon(ctx: Context, pkg: String): ImageBitmap? =
    runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap() }.getOrNull()

private fun envIcon(ctx: Context, env: CloneEntity): ImageBitmap? =
    env.customIconPath?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } ?: appIcon(ctx, env.packageName)

@Composable
fun EnvIcon(env: CloneEntity, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(env.packageName, env.customIconPath) { envIcon(ctx, env) }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.28f))
            .background(Color(env.accentColor).copy(alpha = 0.20f)),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            val fill = if (env.customIconPath != null) 1f else 0.72f
            Image(bmp, null, Modifier.fillMaxSize(fill))
        } else {
            Icon(Icons.Rounded.Apps, null, tint = Color(env.accentColor))
        }
    }
}

@Composable
fun AppIconImage(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) { appIcon(ctx, pkg) }
    if (bmp != null) Image(bmp, null, Modifier.size(size)) else Icon(Icons.Rounded.Apps, null, Modifier.size(size))
}

@Composable
fun stateLabel(s: EnvState): String = stringResource(
    when (s) {
        EnvState.READY -> R.string.state_ready
        EnvState.LAUNCHING -> R.string.state_launching
        EnvState.ERROR -> R.string.state_error
    },
)

@Composable
fun StateChip(s: EnvState) {
    val scheme = MaterialTheme.colorScheme
    val bg = when (s) {
        EnvState.READY -> scheme.primaryContainer
        EnvState.LAUNCHING -> scheme.tertiaryContainer
        EnvState.ERROR -> scheme.errorContainer
    }
    Surface(shape = RoundedCornerShape(50), color = bg) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (s == EnvState.LAUNCHING) {
                CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(6.dp))
            }
            Text(stateLabel(s), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun CloneCard(
    env: CloneEntity,
    onLaunch: () -> Unit,
    onDetails: () -> Unit,
    onFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val star by animateColorAsState(
        if (env.favorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.outline, label = "star",
    )
    Card(
        onClick = onLaunch,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(env.accentColor).copy(alpha = 0.10f).compositeOver(MaterialTheme.colorScheme.surface),
        ),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                EnvIcon(env, 56.dp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onFavorite, Modifier.size(36.dp)) {
                    Icon(
                        if (env.favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                        stringResource(R.string.favorite), tint = star,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(env.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(env.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                StateChip(env.state)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDetails, Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.Info, stringResource(R.string.details))
                }
            }
        }
    }
}

@Composable
fun InfoBanner(text: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Info, null)
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun EmptyState(storeEmpty: Boolean) {
    Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.Apps, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text(stringResource(if (storeEmpty) R.string.empty_title else R.string.no_results), style = MaterialTheme.typography.titleMedium)
        if (storeEmpty) Text(stringResource(R.string.empty_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(0.4f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium)
    }
}
