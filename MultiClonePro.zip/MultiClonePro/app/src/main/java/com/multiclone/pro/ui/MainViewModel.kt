package com.multiclone.pro.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.multiclone.pro.MultiCloneApp
import com.multiclone.pro.R
import com.multiclone.pro.data.CloneEntity
import com.multiclone.pro.data.InstalledApp
import com.multiclone.pro.domain.SortMode
import com.multiclone.pro.domain.ThemeMode
import com.multiclone.pro.domain.filterAndSort
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiMessage(@StringRes val res: Int, val arg: String? = null) {
    fun resolve(ctx: Context): String = if (arg == null) ctx.getString(res) else ctx.getString(res, arg)
}

data class MainUiState(
    val loaded: Boolean = false,
    val items: List<CloneEntity> = emptyList(),
    val storeEmpty: Boolean = true,
    val query: String = "",
    val favoritesOnly: Boolean = false,
    val sort: SortMode = SortMode.MANUAL,
    val theme: ThemeMode = ThemeMode.SYSTEM,
) {
    val canReorder get() = sort == SortMode.MANUAL && query.isBlank() && !favoritesOnly
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as MultiCloneApp).container
    private val repo = c.repository
    private val settings = c.settings

    val capabilities = c.engine.capabilities

    private val query = MutableStateFlow("")
    private val favoritesOnly = MutableStateFlow(false)

    val state: StateFlow<MainUiState> = combine(
        repo.environments, query, favoritesOnly, settings.sortMode, settings.themeMode,
    ) { all, q, fav, sort, theme ->
        MainUiState(true, all.filterAndSort(q, fav, sort), all.isEmpty(), q, fav, sort, theme)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MainUiState())

    private val _messages = Channel<UiMessage>(Channel.BUFFERED)
    val messages: Flow<UiMessage> = _messages.receiveAsFlow()

    private val _apps = MutableStateFlow<List<InstalledApp>?>(null)
    val apps: StateFlow<List<InstalledApp>?> = _apps.asStateFlow()

    private fun say(res: Int, arg: String? = null) { _messages.trySend(UiMessage(res, arg)) }

    fun observe(id: Long): Flow<CloneEntity?> = repo.environments.map { l -> l.firstOrNull { it.id == id } }
    suspend fun storageBytes(id: Long): Long = withContext(Dispatchers.IO) { c.engine.storageBytes(id) }

    fun setQuery(q: String) { query.value = q }
    fun setFavoritesOnly(v: Boolean) { favoritesOnly.value = v }
    fun setSort(m: SortMode) = viewModelScope.launch { settings.setSort(m) }
    fun setTheme(m: ThemeMode) = viewModelScope.launch { settings.setTheme(m) }

    fun loadApps() = viewModelScope.launch { _apps.value = c.installedApps.load() }

    fun create(app: InstalledApp, name: String) = viewModelScope.launch {
        repo.create(app, name)
            .onSuccess { say(R.string.msg_created, name.trim()) }
            .onFailure { say(R.string.error_prepare, it.message ?: "") }
    }

    fun rename(id: Long, name: String) = viewModelScope.launch { repo.rename(id, name) }
    fun toggleFavorite(id: Long) = viewModelScope.launch { repo.toggleFavorite(id) }
    fun setAccent(id: Long, color: Int) = viewModelScope.launch { repo.setAccent(id, color) }
    fun move(id: Long, delta: Int) = viewModelScope.launch { repo.move(id, delta) }
    fun resetIcon(id: Long) = viewModelScope.launch { repo.resetIcon(id) }

    fun setCustomIcon(id: Long, uri: Uri) = viewModelScope.launch {
        repo.setCustomIcon(id, uri).onFailure { say(R.string.msg_icon_failed) }
    }

    fun launch(id: Long) = viewModelScope.launch {
        repo.launch(id).onFailure { say(R.string.msg_launch_failed, it.message ?: "") }
    }

    fun delete(id: Long) = viewModelScope.launch {
        repo.delete(id).onFailure { say(R.string.msg_delete_failed, it.message ?: "") }
    }
}
