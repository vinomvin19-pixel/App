package com.multiclone.counter

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun watched(c: Context): Set<String> = sp(c).getStringSet("watched", emptySet())?.toSet() ?: emptySet()
    fun setWatched(c: Context, s: Set<String>) { sp(c).edit().putStringSet("watched", s.toSet()).apply() }
    fun keyword(c: Context): String = sp(c).getString("keyword", "") ?: ""
    fun setKeyword(c: Context, v: String) { sp(c).edit().putString("keyword", v).apply() }
}
