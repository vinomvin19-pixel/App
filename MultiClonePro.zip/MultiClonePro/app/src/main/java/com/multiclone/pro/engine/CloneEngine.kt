package com.multiclone.pro.engine

import com.multiclone.pro.data.CloneEntity
import java.io.File

data class EngineCapabilities(
    val name: String,
    val isolatesAppData: Boolean,
    val supportsMultipleInstances: Boolean,
)

/**
 * Isolation backend. The UI and data layers only talk to this interface, so a real
 * virtualization engine (Phase 2) can replace [LauncherEngine] without touching them.
 */
interface CloneEngine {
    val capabilities: EngineCapabilities
    suspend fun prepare(env: CloneEntity): Result<File>
    suspend fun launch(env: CloneEntity): Result<Unit>
    suspend fun destroy(env: CloneEntity): Result<Unit>
    fun storageBytes(envId: Long): Long
}
