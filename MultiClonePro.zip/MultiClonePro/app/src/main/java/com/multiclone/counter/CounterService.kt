package com.multiclone.counter

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class CounterService : NotificationListenerService() {

    override fun onListenerConnected() { refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }

    private fun refresh() {
        val active = runCatching { getActiveNotifications() }.getOrNull() ?: emptyArray()
        val list = active
            .filter { it.packageName != packageName }
            .mapNotNull { toItem(it) }
        NotifStore.update(applicationContext, list)
    }

    @Suppress("DEPRECATION")
    private fun toItem(sbn: StatusBarNotification): NotifItem? {
        val n = sbn.notification ?: return null
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)?.size ?: 0
        val count = if (msgs > 0) msgs else maxOf(1, n.number)
        val label = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        val ongoing = n.flags and Notification.FLAG_ONGOING_EVENT != 0
        return NotifItem(sbn.key, sbn.packageName, label, title, text, sub, count, ongoing)
    }
}
