package com.multiclone.pro.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import com.multiclone.pro.domain.Palette
import com.multiclone.pro.engine.CloneEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class CloneRepository(
    private val context: Context,
    private val dao: CloneDao,
    private val engine: CloneEngine,
) {
    val environments: Flow<List<CloneEntity>> = dao.observeAll()

    private val iconsDir get() = File(context.filesDir, "icons").apply { mkdirs() }

    suspend fun create(app: InstalledApp, name: String): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val clean = name.trim()
            require(clean.isNotEmpty()) { "empty name" }
            val order = dao.maxOrder() + 1
            val entity = CloneEntity(
                name = clean, packageName = app.packageName,
                accentColor = Palette.pick(order), sortOrder = order,
                createdAt = System.currentTimeMillis(),
            )
            val id = dao.insert(entity)
            engine.prepare(entity.copy(id = id)).onFailure { dao.delete(id) }.getOrThrow()
            id
        }
    }

    suspend fun rename(id: Long, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val clean = name.trim()
            require(clean.isNotEmpty())
            dao.get(id)?.let { dao.update(it.copy(name = clean)) }
            Unit
        }
    }

    suspend fun toggleFavorite(id: Long) = withContext(Dispatchers.IO) {
        dao.get(id)?.let { dao.update(it.copy(favorite = !it.favorite)) }
    }

    suspend fun setAccent(id: Long, color: Int) = withContext(Dispatchers.IO) {
        dao.get(id)?.let { dao.update(it.copy(accentColor = color)) }
    }

    /** Swaps position in the manual order; [delta] is -1 or +1. */
    suspend fun move(id: Long, delta: Int) = withContext(Dispatchers.IO) {
        val list = dao.getAllOnce().toMutableList()
        val from = list.indexOfFirst { it.id == id }
        val to = from + delta
        if (from < 0 || to !in list.indices) return@withContext
        list.add(to, list.removeAt(from))
        dao.updateAll(list.mapIndexed { i, e -> e.copy(sortOrder = i) })
    }

    suspend fun setCustomIcon(id: Long, uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val env = dao.get(id) ?: error("missing")
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
            val bmp = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: error("decode failed")
            val thumb = ThumbnailUtils.extractThumbnail(bmp, 192, 192)
            val file = File(iconsDir, "${id}_${System.currentTimeMillis()}.png")
            file.outputStream().use { thumb.compress(Bitmap.CompressFormat.PNG, 100, it) }
            env.customIconPath?.let { File(it).delete() }
            dao.update(env.copy(customIconPath = file.absolutePath))
        }
    }

    suspend fun resetIcon(id: Long) = withContext(Dispatchers.IO) {
        dao.get(id)?.let {
            it.customIconPath?.let { p -> File(p).delete() }
            dao.update(it.copy(customIconPath = null))
        }
    }

    suspend fun launch(id: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val env = dao.get(id) ?: return@withContext Result.failure(IllegalStateException("missing"))
        dao.update(env.copy(state = EnvState.LAUNCHING, lastError = null))
        val result = engine.launch(env)
        dao.get(id)?.let { cur ->
            dao.update(
                if (result.isSuccess) cur.copy(state = EnvState.READY, lastLaunchedAt = System.currentTimeMillis(), lastError = null)
                else cur.copy(state = EnvState.ERROR, lastError = result.exceptionOrNull()?.message),
            )
        }
        result
    }

    suspend fun delete(id: Long): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val env = dao.get(id) ?: return@runCatching
            engine.destroy(env).getOrThrow()
            env.customIconPath?.let { File(it).delete() }
            dao.delete(id)
        }
    }
}
