# MultiClone Pro (Phase 1)

## Build
1. Android Studio Koala (2024.1.1) or newer, JDK 17.
2. File > Open > this folder. Accept the Gradle sync (downloads Gradle 8.9 and dependencies).
3. Debug APK: Build > Build APK(s), or `./gradlew assembleDebug` -> app/build/outputs/apk/debug/
4. Unit tests: `./gradlew testDebugUnitTest`

## What works for real (Phase 1)
Create / rename / delete environments, change icon (color or image), favorites, search, sort (manual/name/newest),
move in manual order, per-environment info, persisted in Room + DataStore, light/dark, Arabic/English (RTL),
launch state + error handling.

## What it does NOT do
The Phase 1 engine launches the original installed app. Data is NOT isolated. Isolation needs a Work Profile
(one copy) or a user-space virtualization engine (Phase 2) plugged in behind `engine/CloneEngine`.

## Manual test checklist
Create 20+ environments; rotate device; switch language/theme; uninstall an original app then launch its environment
(must show a clear error); delete an environment (its folder under files/environments is removed);
use LeakCanary (debug build) and Android Studio Profiler > Memory while scrolling the grid.

## Build the APK without a PC (GitHub Actions)
Upload this project to a new GitHub repository (keep the .github folder). Open the Actions tab,
run "Build APK", then download the artifact MultiClonePro-debug-apk (a zip containing app-debug.apk).
